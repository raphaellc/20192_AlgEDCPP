#include "Mago.h"

Mago::Mago()
{
}

Mago::~Mago()
{
}
