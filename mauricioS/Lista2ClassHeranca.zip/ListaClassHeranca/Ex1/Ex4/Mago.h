#pragma once
#include "Personagem.h"

class Mago : virtual protected Personagem
{
public:
	Mago();
	~Mago();
};

