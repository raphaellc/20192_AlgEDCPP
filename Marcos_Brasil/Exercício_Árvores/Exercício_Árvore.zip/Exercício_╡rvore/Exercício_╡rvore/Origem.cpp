#include <iostream>
#include "ArvoreBinaria.h"

using namespace std;

int main() {

	ArvoreBinaria arvore;

	arvore.inserir(10);
	arvore.inserir(5);
	arvore.inserir(20);
	arvore.inserir(3);
	arvore.inserir(7);
	arvore.inserir(11);
	arvore.inserir(22);
	arvore.inserir(6);
	arvore.inserir(8);

	arvore.visitarPreOrdem();
	cout << endl;
	arvore.visitarCentral();
	cout << endl;
	arvore.visitarPosOrdem();
	cout << endl;


	system("pause");
	return 0;
}